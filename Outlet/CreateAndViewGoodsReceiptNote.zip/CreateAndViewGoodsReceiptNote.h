//
//  CreateAndViewGoodsReceiptNote.h
//  OmniRetailer
//
//  Created by Srinivasulu on 10/21/16.
//
//

#import "CustomNavigationController.h"

#import "MBProgressHUD.h"
#import <AudioToolbox/AudioToolbox.h>


#import "WebServiceUtility.h"
#import "WebServiceConstants.h"
#import "WebServiceController.h"

#import "RequestHeader.h"
#import "PopOverViewController.h"

#import "CustomLabel.h"

#import "CustomTextField.h"
#import "CustomNavigationController.h"


@interface CreateAndViewGoodsReceiptNote : CustomNavigationController<MBProgressHUDDelegate,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,WarehouseGoodsReceipNoteServiceDelegate,UITextFieldDelegate,SearchProductsDelegate,GetSKUDetailsDelegate,UIAlertViewDelegate,NSXMLParserDelegate,UIGestureRecognizerDelegate,EmployeeServiceDelegate>
{
    
    //to get the device version.......
    float version;
    
    //used to store the device Orientation.......
    UIDeviceOrientation currentOrientation;
    
    
    //used for HUD..(processing bar).......
    MBProgressHUD *HUD;
    
    
    //used to create completeView.....
    UIView *purchaseOrderView;
    
    
    //used for workFlowView.......
    UIView *workFlowView;
    
    
    //used to scroll completeView.......
    UIScrollView *purchaseOrderScrollView;
    
    
    //used to take customerInputs selection.......
    CustomTextField *poRefNoTxt;
    CustomTextField *dueDateTxt;
    CustomTextField *deliveredDateTxt;
    
    CustomTextField *vendorIdTxt;
    CustomTextField *supplierNameTxt;
    
    CustomTextField *inspectedByTxt;
    CustomTextField *receivedByTxt;
    CustomTextField *deliveredByTxt;
    
    CustomTextField *submitedByTxt;
    CustomTextField *approvedByTxt;
  
    
    CustomTextField *actionRequiredTxt;

    
    CustomTextField *searchItemsTxt;
    
    
    NSString *searchString;
    NSMutableArray *searchResultItemsArr;
    NSMutableArray *searchDisplayItemsArr;
    
    UITableView *searchOrderItemTbl;

    
    //UILabel used here.......
    UILabel *wareHouseIdLbl;
    
   
    //Used on TopOfTable.......
    CustomLabel  *sNoLbl;
    CustomLabel  *skuIdLbl;
    CustomLabel  *descriptionLbl;
    CustomLabel  *uomLbl;
    CustomLabel  *poQtyLbl;
    CustomLabel  *poPriceLbl;
    CustomLabel  *delveredQtyLbl;
    CustomLabel  *delveredPriceLbl;
    CustomLabel  *netCostLbl;

    
    //UITableView .......
    UITableView *requestedItemsTbl;
    NSMutableArray *requestedItemsInfoArr;
    
    //used to move the scrollView.......
    UIView *adjustableView;
  
    //used for calcuation part.......
    UILabel *subTotalValueLbl;
    UILabel *shipmentAmountValueLbl;
    
    UILabel *taxValueLbl;
    UILabel *totalCostValueLbl;
    
    float shipmentCost;
    float totalTax;
    
    
    UIImageView *starRat;
  
    
    
    NSMutableDictionary *goodsReceiptNoteInfoDic;

    
    //Used to display the all VendorIds.......
    NSMutableArray *vendorIdArr;
    NSMutableDictionary *vendorIdDic;
    UITableView *vendorIdsTbl;
    int vendorRating;
    
    
    
    
    //Used to display all popUp view.......
    UIPopoverController *catPopOver;
    
    
    //Used to show dataSelectionPopUp.......
    UIView *pickView;
    UIDatePicker *myPicker;
    NSString *dateString;

    
    //used for keyboard apperance.......
    float offSetViewTo;

    UIAlertView *successAlert;

 
    
    UILabel *headerNameLbl;
    
    
    UIButton *saveBtn;
    UIButton *editBtn;
    UIButton *cancelBtn ;
    
    
    
    UITableView *nextActivitiesTbl;
    NSMutableArray *nextActivitiesArr;
    
    
    
    UITextField *poQtyTxt;
    UITextField *divrdQtyTxt;
    
    BOOL didTableDataEditing;

    
    UILabel *userAlertMessageLbl;
    NSTimer *fadOutTime;
    
    
    UIButton *vendorIdBtn;
    
    UIButton *dueDateBtn;
    UIButton *deliveryDateBtn;
    
    
    //used for parser the xml data....
    NSXMLParser *parserXml;
    NSMutableDictionary *xmlViewCategotriesInfoDic;
    
    
    //added by srinivasulu on 07/02/2017...
    
    UIButton *items_Save_R_Delete_Btn;
    
    //upto here on 07/02/2017....
    
    //added on 07/02/2017....
    UITextField *divrdPriceTxt;

    //used to show dropDowns....
    UIButton *inspectdByBtn;
    UIButton *receivedByBtn;
    
    //Used to display the all VendorIds.......
    NSMutableArray *employeesListArr;
    UITableView *employeesListTbl;
    
    //used in table hander's....
    CustomLabel  *itemHandledByLbl;
    UILabel *item_Handled_By_Lbl;
    
    
    //used to take input from user....
    CustomTextField *invoiceNumberTxt;
    
    
}


@property (readwrite)	CFURLRef		soundFileURLRef;
@property (readonly)	SystemSoundID	soundFileObject;

@property (nonatomic,retain)NSString *goodsReceiptRefID;
@property (nonatomic,retain)NSString *selectedString;


@end
